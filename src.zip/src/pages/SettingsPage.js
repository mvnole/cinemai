import React from "react";

export function SettingsPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Settings</h2>
      <p>Aici vor fi opțiunile de setări pentru aplicația ta.</p>
    </div>
  );
}